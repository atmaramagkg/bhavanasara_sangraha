import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/lila_period.dart';
import '../services/bss_repository.dart';
import '../widgets/top_period_nav.dart';
import '../widgets/right_number_rail.dart';

class ReadingScreen extends StatefulWidget {
  final BssRepository repository;
  final int initialPeriodId;

  const ReadingScreen({
    super.key,
    required this.repository,
    this.initialPeriodId = 1,
  });

  @override
  State<ReadingScreen> createState() => _ReadingScreenState();
}

class _ReadingScreenState extends State<ReadingScreen> {
  final ScrollController _scrollController = ScrollController();
  final Map<int, GlobalKey> _sectionKeys = {};

  List<LilaPeriod> _mainPeriods = [];
  List<SubPeriod> _currentSubPeriods = [];
  List<ContinuousReadingItem> _feedItems = [];

  int _selectedMainPeriodId = 1;
  int _selectedSubPeriodId = -1;
  int _selectedSectionId = -1;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _selectedMainPeriodId = widget.initialPeriodId;
    _scrollController.addListener(_onScroll);
    _initializeData();
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  int _timeToMinutes(String timeStr) {
    try {
      final parts = timeStr.trim().split(':');
      if (parts.length >= 2) {
        final h = int.parse(parts[0]);
        final m = int.parse(parts[1]);
        return h * 60 + m;
      }
    } catch (_) {}
    return -1;
  }

  bool _isCurrentTimeInRange(String startStr, String endStr, int currentMinutes) {
    final start = _timeToMinutes(startStr);
    final end = _timeToMinutes(endStr);
    if (start == -1 || end == -1) return false;

    if (start < end) {
      return currentMinutes >= start && currentMinutes < end;
    } else {
      return currentMinutes >= start || currentMinutes < end;
    }
  }

  Future<void> _initializeData() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    final List<LilaPeriod> mainPeriods = await widget.repository.getMainPeriods();
    final List<ContinuousReadingItem> feedItems = await widget.repository.loadFullContinuousFeed();

    if (!mounted) return;

    _sectionKeys.clear();
    for (final item in feedItems) {
      _sectionKeys[item.section.id] = GlobalKey();
    }

    _mainPeriods = mainPeriods;
    _feedItems = feedItems;

    final now = DateTime.now();
    final currentMinutes = now.hour * 60 + now.minute;
    int targetSectionId = -1;

    for (final item in feedItems) {
      if (item.subPeriod.timeRange.contains('-')) {
        final parts = item.subPeriod.timeRange.split('-');
        if (parts.length == 2 && _isCurrentTimeInRange(parts[0], parts[1], currentMinutes)) {
          _selectedMainPeriodId = item.mainPeriod.id;
          _selectedSubPeriodId = item.subPeriod.id;
          targetSectionId = item.section.id;
          break;
        }
      }
    }

    if (_selectedSubPeriodId == -1 && feedItems.isNotEmpty) {
      _selectedMainPeriodId = feedItems.first.mainPeriod.id;
      _selectedSubPeriodId = feedItems.first.subPeriod.id;
      targetSectionId = feedItems.first.section.id;
    }

    final subPeriods = await widget.repository.getSubPeriods(_selectedMainPeriodId);
    if (!mounted) return;

    setState(() {
      _currentSubPeriods = subPeriods;
      _selectedSectionId = targetSectionId;
      _isLoading = false;
    });

    if (targetSectionId != -1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToSection(targetSectionId);
      });
    }
  }

  void _onScroll() {
    if (_feedItems.isEmpty || !_scrollController.hasClients) return;

    for (final item in _feedItems) {
      final key = _sectionKeys[item.section.id];
      if (key?.currentContext != null) {
        final renderBox = key!.currentContext!.findRenderObject() as RenderBox?;
        if (renderBox != null) {
          final position = renderBox.localToGlobal(Offset.zero);
          if (position.dy >= 0 && position.dy <= 350) {
            if (_selectedSectionId != item.section.id ||
                _selectedSubPeriodId != item.subPeriod.id ||
                _selectedMainPeriodId != item.mainPeriod.id) {
              
              _updateActiveNavigation(item.mainPeriod.id, item.subPeriod.id, item.section.id);
            }
            break;
          }
        }
      }
    }
  }

  Future<void> _updateActiveNavigation(int mainId, int subId, int secId) async {
    List<SubPeriod> subPeriods = _currentSubPeriods;
    if (mainId != _selectedMainPeriodId) {
      subPeriods = await widget.repository.getSubPeriods(mainId);
    }
    if (!mounted) return;

    setState(() {
      _selectedMainPeriodId = mainId;
      _selectedSubPeriodId = subId;
      _selectedSectionId = secId;
      _currentSubPeriods = subPeriods;
    });
  }

  void _scrollToSection(int sectionId) {
    final key = _sectionKeys[sectionId];
    if (key != null && key.currentContext != null) {
      Scrollable.ensureVisible(
        key.currentContext!,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        alignment: 0.0,
      );
      setState(() => _selectedSectionId = sectionId);
    } else {
      final index = _feedItems.indexWhere((item) => item.section.id == sectionId);
      if (index != -1 && _scrollController.hasClients) {
        setState(() => _selectedSectionId = sectionId);
        _scrollController.animateTo(
          index * 380.0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      }
    }
  }

  Future<void> _onMainPeriodTabSelected(int mainPeriodId) async {
    final subPeriods = await widget.repository.getSubPeriods(mainPeriodId);
    final index = _feedItems.indexWhere((item) => item.mainPeriod.id == mainPeriodId);
    
    if (!mounted) return;
    setState(() {
      _selectedMainPeriodId = mainPeriodId;
      _currentSubPeriods = subPeriods;
      if (subPeriods.isNotEmpty) {
        _selectedSubPeriodId = subPeriods.first.id;
      }
    });

    if (index != -1) {
      _scrollToSection(_feedItems[index].section.id);
    }
  }

  void _onSubPeriodSelected(int subPeriodId) {
    final index = _feedItems.indexWhere((item) => item.subPeriod.id == subPeriodId);
    if (index != -1) {
      _scrollToSection(_feedItems[index].section.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final goldColor = isDark ? BssColors.darkOakGold : BssColors.goldAccent;
    final cardBg = isDark ? BssColors.darkOakCard : BssColors.parchmentCard;
    final textColor = isDark ? BssColors.darkOakText : BssColors.darkText;

    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final activeRailSections = _feedItems
        .where((item) => item.subPeriod.id == _selectedSubPeriodId)
        .map((item) => item.section)
        .toList();

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          'Bhāvanāsāra Saṅgraha',
          style: TextStyle(fontFamily: 'Serif', fontSize: 18),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.bookmark_border, color: goldColor),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.menu, color: goldColor),
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            TopPeriodNav(
              mainPeriods: _mainPeriods,
              selectedMainPeriodId: _selectedMainPeriodId,
              onMainPeriodSelected: _onMainPeriodTabSelected,
              subPeriods: _currentSubPeriods,
              selectedSubPeriodId: _selectedSubPeriodId,
              onSubPeriodSelected: _onSubPeriodSelected,
            ),
            Expanded(
              child: Stack(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.only(left: 0.0, right: 54.0, top: 4.0, bottom: 24.0),
                          itemCount: _feedItems.length,
                          itemBuilder: (context, index) {
                            final item = _feedItems[index];
                            final key = _sectionKeys[item.section.id];

                            return Container(
                              key: key,
                              margin: const EdgeInsets.only(bottom: 12.0, left: 0.0, right: 4.0),
                              padding: const EdgeInsets.all(14.0),
                              decoration: BoxDecoration(
                                color: cardBg,
                                borderRadius: const BorderRadius.only(
                                  topRight: Radius.circular(10.0),
                                  bottomRight: Radius.circular(10.0),
                                ),
                                border: Border.all(
                                  color: goldColor.withAlpha(102),
                                  width: 1.0,
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  if (item.isFirstInMainPeriod) ...[
                                    Container(
                                      padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 8.0),
                                      margin: const EdgeInsets.only(bottom: 10.0),
                                      decoration: BoxDecoration(
                                        color: goldColor.withAlpha(38),
                                        borderRadius: BorderRadius.circular(6.0),
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            item.mainPeriod.id == 1 || item.mainPeriod.id >= 7
                                                ? Icons.nightlight_round
                                                : Icons.wb_sunny_outlined,
                                            color: goldColor,
                                            size: 18,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            '${item.mainPeriod.title}-līlā (${item.mainPeriod.timeRange})',
                                            style: TextStyle(
                                              fontFamily: 'Serif',
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: textColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],

                                  if (item.isFirstInSubPeriod) ...[
                                    Padding(
                                      padding: const EdgeInsets.only(bottom: 6.0),
                                      child: Center(
                                        child: Text(
                                          'Subperiod: ${item.subPeriod.timeRange}',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: goldColor,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],

                                  Text(
                                    item.section.title,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontFamily: 'Serif',
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      color: textColor,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  const Divider(height: 1),
                                  const SizedBox(height: 10),

                                  ...item.verses.map((verse) {
                                    return Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        SelectableText(
                                          verse.quoteText,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Serif',
                                            fontSize: 15,
                                            height: 1.5,
                                            color: textColor,
                                          ),
                                        ),
                                        const SizedBox(height: 6),
                                        Text(
                                          '— ${verse.bookTitle} (${verse.refDisplay})',
                                          textAlign: TextAlign.right,
                                          style: TextStyle(
                                            fontFamily: 'Serif',
                                            fontSize: 11,
                                            fontStyle: FontStyle.italic,
                                            color: goldColor,
                                          ),
                                        ),
                                        const SizedBox(height: 12),
                                      ],
                                    );
                                  }),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),

                  Positioned(
                    right: 0,
                    top: 0,
                    bottom: 0,
                    child: RightNumberRail(
                      sections: activeRailSections,
                      selectedSectionId: _selectedSectionId,
                      onSectionSelected: (secId) => _scrollToSection(secId),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}